import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const inputSchema = z.object({
  oferta: z.string().trim().min(20).max(8000),
  cv: z.object({
    titulo: z.string().max(200),
    perfil: z.string().max(3000),
    experiencia: z.array(z.object({ puesto: z.string().max(200), empresa: z.string().max(200), detalle: z.string().max(3000) })).max(20),
    habilidades: z.string().max(2000),
  }),
});

const outSchema = z.object({
  titulo: z.string(),
  perfil: z.string(),
  detalles: z.array(z.string()),
  habilidades: z.string(),
});

export const adaptarCV = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => inputSchema.parse(d))
  .handler(async ({ data }) => {
    const key = process.env['LOVABLE_API_KEY'];
    if (!key) return { error: "El servicio no está configurado." };
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText, Output, NoObjectGeneratedError } = await import("ai");
    const openai = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey: key,
      headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });
    const prompt = `Oferta de trabajo:\n${data.oferta}\n\nCV actual (JSON):\n${JSON.stringify(data.cv)}\n\nAdaptá el CV a esta oferta en español. Reglas: NO inventes experiencia, estudios ni habilidades que la persona no tenga; solo reescribí, reordená y resaltá lo relevante usando palabras clave de la oferta (útil para filtros ATS). Devolvé: titulo (puesto alineado a la oferta), perfil (3-4 oraciones), detalles (un texto por cada experiencia, en el mismo orden y cantidad que recibiste, viñetas separadas por salto de línea empezando con "• "), habilidades (lista separada por comas, las más relevantes primero; podés incluir habilidades blandas evidentes de su experiencia).`;
    try {
      const result = streamText({
        model: openai.responses("openai/gpt-6-astra"),
        prompt,
        output: Output.object({ schema: outSchema }),
        providerOptions: { openai: { forceReasoning: true, reasoningEffort: "low", store: false } },
      });
      let out: z.infer<typeof outSchema>;
      try {
        out = (await result.output) as z.infer<typeof outSchema>;
      } catch (e) {
        const txt = NoObjectGeneratedError.isInstance(e) ? (e as { text?: string }).text : undefined;
        if (txt) out = outSchema.parse(JSON.parse(txt));
        else throw e;
      }
      return { data: out };
    } catch (e: any) {
      console.error("adaptarCV", e);
      const status = e?.statusCode ?? e?.status;
      if (status === 429) return { error: "Hay muchas solicitudes ahora. Probá en un minuto." };
      if (status === 402) return { error: "Se agotaron los créditos de IA." };
      return { error: "No pudimos adaptar el CV. Intentá de nuevo." };
    }
  });
