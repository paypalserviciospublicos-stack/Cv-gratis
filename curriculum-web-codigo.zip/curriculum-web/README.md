# Generador de Currículums

Web para que una persona cargue sus datos, elija un diseño y descargue su currículum en PDF o en Word.

## Qué hace

- Pide datos personales (nombre, puesto, contacto, ciudad, "Sobre mí") y una foto opcional.
- Permite cargar experiencia laboral, estudios, habilidades e idiomas.
- Cuatro diseños para elegir: **Clásico**, **Moderno**, **Minimal** y **ATS** (este último sin foto y en una sola columna, pensado para los programas que usan las empresas para leer currículums).
- Vista previa en vivo: el currículum se ve mientras se escribe.
- **Descargar PDF**: abre la ventana de impresión del navegador; ahí se elige "Guardar como PDF".
- **Descargar Word**: genera un archivo `.docx` real.
- **Adaptar a esta oferta**: se pega el aviso de trabajo y la inteligencia artificial reescribe el puesto buscado, el "Sobre mí", las tareas y las habilidades con las palabras de la oferta, sin inventar experiencia.

## Requisitos

Node.js 20 o más reciente y npm.

## Instalar y correr

```sh
npm install
npm run dev
```

Abrí la dirección que muestra la terminal (por defecto http://localhost:8080).

## Comandos

| Comando | Para qué sirve |
| --- | --- |
| `npm run dev` | Correr la web en la computadora |
| `npm run build` | Generar la versión lista para publicar |
| `npm run preview` | Probar la versión generada |
| `npm run test` | Correr las pruebas |
| `npm run lint` | Revisar el código |

## Configuración

Los datos personales **no se guardan en ningún lado**: todo queda en la memoria del navegador hasta que se descarga el archivo.

La función "Adaptar a esta oferta" usa un backend con inteligencia artificial. La conexión está en `src/integrations/supabase/client.ts` y apunta al backend con el que se construyó esta web; si querés usarlo en otro proyecto, reemplazá esos valores por los de tu propio backend (los mismos de `.env.example`) y activá la función `adaptar_cv` del lado del servidor.

Sin esa conexión, el resto de la web (cargar datos, elegir diseño, descargar PDF o Word) funciona igual.

## Estructura

```text
src/
  routes/
    index.tsx        La página completa: formulario, vista previa y descarga
    __root.tsx       Encabezado, tipografías y estilos base
  lib/
    word.ts          Genera el archivo de Word (.docx)
    adaptar.functions.ts  Llama a la inteligencia artificial para adaptar el CV
  styles.css         Estilos y reglas de impresión (PDF)
  components/ui/     Piezas de interfaz reutilizables
```

## Tecnologías

TanStack Start (React 19 + Vite), TypeScript, Tailwind CSS 4, lucide-react, docx.
