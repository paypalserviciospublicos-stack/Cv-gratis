import { createFileRoute } from "@tanstack/react-router";
import { useState, type ChangeEvent, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { adaptarCV } from "@/lib/adaptar.functions";
import { generarWord, downloadBlob } from "@/lib/word";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Armá tu CV gratis | Creador de currículum" },
      { name: "description", content: "Completá tus datos, sumá tu foto, elegí un diseño y descargá tu currículum en PDF." },
      { property: "og:title", content: "Armá tu CV gratis" },
      { property: "og:description", content: "Creá y descargá tu currículum vitae en minutos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type Exp = { puesto: string; empresa: string; periodo: string; detalle: string };
type Edu = { titulo: string; institucion: string; periodo: string };
type Data = {
  nombre: string; titulo: string; email: string; telefono: string; ciudad: string;
  perfil: string; foto: string | null; experiencia: Exp[]; educacion: Edu[];
  habilidades: string; idiomas: string;
};
type Formato = "clasico" | "moderno" | "minimal" | "ats";

const vacio: Data = {
  nombre: "", titulo: "", email: "", telefono: "", ciudad: "", perfil: "", foto: null,
  experiencia: [{ puesto: "", empresa: "", periodo: "", detalle: "" }],
  educacion: [{ titulo: "", institucion: "", periodo: "" }],
  habilidades: "", idiomas: "",
};

function Index() {
  const [d, setD] = useState<Data>(vacio);
  const [formato, setFormato] = useState<Formato>("moderno");
  const [oferta, setOferta] = useState("");
  const [cargando, setCargando] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [original, setOriginal] = useState<Data | null>(null);
  const adaptar = useServerFn(adaptarCV);

  const onAdaptar = async () => {
    setMsg(null);
    if (oferta.trim().length < 20) return setMsg("Pegá el texto completo de la oferta.");
    setCargando(true);
    try {
      const r = await adaptar({ data: { oferta, cv: { titulo: d.titulo, perfil: d.perfil, habilidades: d.habilidades,
        experiencia: d.experiencia.map(({ puesto, empresa, detalle }) => ({ puesto, empresa, detalle })) } } });
      if ("error" in r && r.error) return setMsg(r.error);
      if ("data" in r && r.data) {
        const a = r.data;
        if (!original) setOriginal(d);
        setD({ ...d, titulo: a.titulo || d.titulo, perfil: a.perfil || d.perfil, habilidades: a.habilidades || d.habilidades,
          experiencia: d.experiencia.map((x, i) => ({ ...x, detalle: a.detalles[i] ?? x.detalle })) });
        setMsg("¡Listo! Revisá los cambios abajo y editá lo que quieras.");
      }
    } catch { setMsg("No pudimos adaptar el CV. Intentá de nuevo."); }
    finally { setCargando(false); }
  };

  const onWord = async () => {
    const blob = await generarWord(d, formato !== "ats");
    downloadBlob(blob, `CV-${(d.nombre || "curriculum").replace(/\s+/g, "-")}.docx`);
  };

  const set = (k: keyof Data) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setD({ ...d, [k]: e.target.value });

  const onFoto = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => setD((p) => ({ ...p, foto: r.result as string }));
    r.readAsDataURL(f);
  };

  const updExp = (i: number, k: keyof Exp, v: string) =>
    setD({ ...d, experiencia: d.experiencia.map((x, j) => (j === i ? { ...x, [k]: v } : x)) });
  const updEdu = (i: number, k: keyof Edu, v: string) =>
    setD({ ...d, educacion: d.educacion.map((x, j) => (j === i ? { ...x, [k]: v } : x)) });

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-7xl px-5 pt-10 pb-6">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">Gratis · Sin registro</p>
        <h1 className="mt-2 text-4xl font-semibold md:text-6xl">Tu currículum, listo para conseguir trabajo.</h1>
        <p className="mt-3 max-w-xl text-muted-foreground">Completá tus datos, sumá tu foto si querés, elegí un diseño y descargalo en PDF.</p>
      </header>

      <main className="mx-auto grid max-w-7xl gap-8 px-5 pb-16 lg:grid-cols-[1fr_1.1fr]">
        <div className="space-y-6">
          <Section n="1" t="Datos personales">
            <div className="flex items-center gap-4">
              <label className="flex h-20 w-20 shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-full border-2 border-dashed border-border bg-muted text-xs text-muted-foreground">
                {d.foto ? <img src={d.foto} alt="Tu foto" className="h-full w-full object-cover" /> : "Foto"}
                <input type="file" accept="image/*" className="hidden" onChange={onFoto} />
              </label>
              <div className="text-sm text-muted-foreground">
                Foto opcional. Tocá el círculo para subirla.
                {d.foto && <button className="ml-2 font-semibold text-destructive" onClick={() => setD({ ...d, foto: null })}>Quitar</button>}
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <input className="field" placeholder="Nombre y apellido" value={d.nombre} onChange={set("nombre")} />
              <input className="field" placeholder="Puesto buscado (ej. Vendedor)" value={d.titulo} onChange={set("titulo")} />
              <input className="field" placeholder="Email" type="email" value={d.email} onChange={set("email")} />
              <input className="field" placeholder="Teléfono" value={d.telefono} onChange={set("telefono")} />
              <input className="field sm:col-span-2" placeholder="Ciudad" value={d.ciudad} onChange={set("ciudad")} />
            </div>
            <textarea className="field min-h-24" placeholder="Sobre mí: contá brevemente quién sos y qué buscás" value={d.perfil} onChange={set("perfil")} />
          </Section>

          <Section n="2" t="Experiencia laboral">
            {d.experiencia.map((x, i) => (
              <div key={i} className="space-y-2 rounded-lg bg-muted p-3">
                <div className="grid gap-2 sm:grid-cols-2">
                  <input className="field" placeholder="Puesto" value={x.puesto} onChange={(e) => updExp(i, "puesto", e.target.value)} />
                  <input className="field" placeholder="Empresa" value={x.empresa} onChange={(e) => updExp(i, "empresa", e.target.value)} />
                  <input className="field sm:col-span-2" placeholder="Período (ej. 2021 – 2024)" value={x.periodo} onChange={(e) => updExp(i, "periodo", e.target.value)} />
                </div>
                <textarea className="field" placeholder="Tareas y logros" value={x.detalle} onChange={(e) => updExp(i, "detalle", e.target.value)} />
                {d.experiencia.length > 1 && <button className="text-sm text-destructive" onClick={() => setD({ ...d, experiencia: d.experiencia.filter((_, j) => j !== i) })}>Eliminar</button>}
              </div>
            ))}
            <AddBtn onClick={() => setD({ ...d, experiencia: [...d.experiencia, { puesto: "", empresa: "", periodo: "", detalle: "" }] })}>Agregar experiencia</AddBtn>
          </Section>

          <Section n="3" t="Estudios">
            {d.educacion.map((x, i) => (
              <div key={i} className="grid gap-2 rounded-lg bg-muted p-3 sm:grid-cols-2">
                <input className="field" placeholder="Título" value={x.titulo} onChange={(e) => updEdu(i, "titulo", e.target.value)} />
                <input className="field" placeholder="Institución" value={x.institucion} onChange={(e) => updEdu(i, "institucion", e.target.value)} />
                <input className="field sm:col-span-2" placeholder="Período" value={x.periodo} onChange={(e) => updEdu(i, "periodo", e.target.value)} />
                {d.educacion.length > 1 && <button className="text-left text-sm text-destructive" onClick={() => setD({ ...d, educacion: d.educacion.filter((_, j) => j !== i) })}>Eliminar</button>}
              </div>
            ))}
            <AddBtn onClick={() => setD({ ...d, educacion: [...d.educacion, { titulo: "", institucion: "", periodo: "" }] })}>Agregar estudio</AddBtn>
          </Section>

          <Section n="4" t="Habilidades e idiomas">
            <input className="field" placeholder="Habilidades separadas por coma (ej. Excel, Atención al cliente)" value={d.habilidades} onChange={set("habilidades")} />
            <input className="field" placeholder="Idiomas separados por coma (ej. Español nativo, Inglés intermedio)" value={d.idiomas} onChange={set("idiomas")} />
          </Section>

          <Section n="5" t="Adaptá tu CV a una oferta">
            <p className="text-sm text-muted-foreground">Pegá el aviso de trabajo y la inteligencia artificial reescribe tu perfil, tareas y habilidades con las palabras clave que busca la empresa. No inventa nada.</p>
            <textarea className="field min-h-32" placeholder="Pegá acá el texto de la oferta de trabajo…" value={oferta} onChange={(e) => setOferta(e.target.value)} />
            <div className="flex flex-wrap items-center gap-3">
              <button onClick={onAdaptar} disabled={cargando} className="rounded-lg bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-60">
                {cargando ? "Adaptando…" : "Adaptar a esta oferta"}
              </button>
              {original && <button onClick={() => { setD(original); setOriginal(null); setMsg("Volviste a tu CV original."); }} className="text-sm font-semibold text-muted-foreground underline">Deshacer cambios</button>}
            </div>
            {msg && <p className="text-sm font-medium text-foreground">{msg}</p>}
          </Section>
        </div>

        <div className="lg:sticky lg:top-6 lg:self-start">
          <Section n="6" t="Elegí el formato">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(["clasico", "moderno", "minimal", "ats"] as Formato[]).map((f) => (
                <button key={f} onClick={() => setFormato(f)}
                  className={`rounded-lg border-2 px-3 py-2 text-sm font-semibold capitalize transition ${formato === f ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card"}`}>
                  {f === "clasico" ? "Clásico" : f === "ats" ? "ATS" : f}
                </button>
              ))}
            </div>
            {formato === "ats" && <p className="text-xs text-muted-foreground">Formato ATS: simple, sin foto ni columnas, para que los sistemas de selección de empresas lean bien tu CV.</p>}
            <div className="overflow-hidden rounded-lg bg-muted p-2">
              <div className="mx-auto w-full overflow-auto">
                <CV d={d} formato={formato} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => window.print()} className="rounded-lg bg-accent py-3.5 font-bold text-accent-foreground shadow-lg transition hover:brightness-105">
                Descargar PDF
              </button>
              <button onClick={onWord} className="rounded-lg border-2 border-primary bg-card py-3.5 font-bold text-primary transition hover:bg-secondary">
                Descargar Word
              </button>
            </div>
            <p className="text-center text-xs text-muted-foreground">PDF: en la ventana que se abre, elegí “Guardar como PDF”. Word: se descarga un archivo editable.</p>
          </Section>
        </div>
      </main>
    </div>
  );
}

function Section({ n, t, children }: { n: string; t: string; children: ReactNode }) {
  return (
    <section className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
      <h2 className="flex items-center gap-3 text-xl font-semibold">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary font-sans text-sm text-primary-foreground">{n}</span>
        {t}
      </h2>
      {children}
    </section>
  );
}

function AddBtn({ onClick, children }: { onClick: () => void; children: ReactNode }) {
  return <button onClick={onClick} className="text-sm font-semibold text-primary">+ {children}</button>;
}

const list = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);

function CV({ d, formato }: { d: Data; formato: Formato }) {
  const nombre = d.nombre || "Tu Nombre";
  const exps = d.experiencia.filter((x) => x.puesto || x.empresa);
  const edus = d.educacion.filter((x) => x.titulo || x.institucion);
  const contacto = [d.email, d.telefono, d.ciudad].filter(Boolean);
  const H = ({ c }: { c: string }) => (
    <h3 className={`mb-2 text-[11px] font-bold uppercase tracking-[0.18em] ${formato === "moderno" ? "text-primary" : "text-ink"} ${formato === "clasico" ? "border-b border-ink pb-1 font-display normal-case tracking-normal text-base" : ""}`}>{c}</h3>
  );
  const Foto = ({ cls }: { cls: string }) => d.foto ? <img src={d.foto} alt="" className={`object-cover ${cls}`} /> : null;

  const cuerpo = (
    <div className="space-y-5">
      {d.perfil && <div><H c="Perfil" /><p className="text-[12px] leading-relaxed text-ink-soft">{d.perfil}</p></div>}
      {exps.length > 0 && <div><H c="Experiencia" />{exps.map((x, i) => (
        <div key={i} className="mb-3">
          <div className="flex justify-between gap-2 text-[12.5px]"><b className="text-ink">{x.puesto}{x.empresa && ` · ${x.empresa}`}</b><span className="shrink-0 text-ink-soft">{x.periodo}</span></div>
          {x.detalle && <p className="mt-0.5 whitespace-pre-line text-[11.5px] text-ink-soft">{x.detalle}</p>}
        </div>))}</div>}
      {edus.length > 0 && <div><H c="Estudios" />{edus.map((x, i) => (
        <div key={i} className="mb-2 flex justify-between gap-2 text-[12px]"><span><b className="text-ink">{x.titulo}</b>{x.institucion && <span className="text-ink-soft"> · {x.institucion}</span>}</span><span className="shrink-0 text-ink-soft">{x.periodo}</span></div>))}</div>}
    </div>
  );
  const extras = (dark: boolean) => (
    <div className="space-y-5">
      {list(d.habilidades).length > 0 && <div><h3 className="mb-2 text-[11px] font-bold uppercase tracking-[0.18em]">Habilidades</h3><ul className={`space-y-1 text-[11.5px] ${dark ? "opacity-90" : "text-ink-soft"}`}>{list(d.habilidades).map((s) => <li key={s}>{s}</li>)}</ul></div>}
      {list(d.idiomas).length > 0 && <div><h3 className="mb-2 text-[11px] font-bold uppercase tracking-[0.18em]">Idiomas</h3><ul className={`space-y-1 text-[11.5px] ${dark ? "opacity-90" : "text-ink-soft"}`}>{list(d.idiomas).map((s) => <li key={s}>{s}</li>)}</ul></div>}
    </div>
  );

  return (
    <div id="cv-print" className="aspect-[210/297] w-full min-w-[340px] bg-paper font-sans text-ink shadow-xl">
      {formato === "moderno" && (
        <div className="grid h-full grid-cols-[34%_1fr]">
          <aside className="space-y-5 bg-primary p-5 text-primary-foreground">
            <Foto cls="mx-auto aspect-square w-full max-w-[120px] rounded-full border-4 border-primary-foreground/30" />
            <div><h3 className="mb-2 text-[11px] font-bold uppercase tracking-[0.18em]">Contacto</h3>{contacto.map((c) => <p key={c} className="break-words text-[11px] opacity-90">{c}</p>)}</div>
            {extras(true)}
          </aside>
          <div className="p-6">
            <h1 className="font-display text-3xl font-semibold leading-tight">{nombre}</h1>
            {d.titulo && <p className="mb-5 text-sm font-semibold text-accent">{d.titulo}</p>}
            {cuerpo}
          </div>
        </div>
      )}
      {formato === "clasico" && (
        <div className="p-8">
          <div className="mb-6 flex items-center gap-5 border-b-2 border-ink pb-4">
            <Foto cls="h-24 w-20 rounded" />
            <div>
              <h1 className="font-display text-3xl font-semibold">{nombre}</h1>
              {d.titulo && <p className="text-sm italic text-ink-soft">{d.titulo}</p>}
              <p className="mt-1 text-[11px] text-ink-soft">{contacto.join("  ·  ")}</p>
            </div>
          </div>
          {cuerpo}
          <div className="mt-5 grid grid-cols-2 gap-4">{extras(false)}</div>
        </div>
      )}
      {formato === "ats" && (
        <div className="p-8 text-ink" style={{ fontFamily: "Arial, sans-serif" }}>
          <h1 className="text-2xl font-bold" style={{ fontFamily: "Arial, sans-serif" }}>{nombre}</h1>
          {d.titulo && <p className="text-[13px] font-bold">{d.titulo}</p>}
          <p className="mt-1 text-[11.5px]">{contacto.join(" | ")}</p>
          {d.perfil && <><h2 className="mt-5 mb-1 border-b border-ink text-[13px] font-bold uppercase" style={{ fontFamily: "Arial, sans-serif" }}>Resumen profesional</h2><p className="text-[11.5px]">{d.perfil}</p></>}
          {exps.length > 0 && <><h2 className="mt-5 mb-1 border-b border-ink text-[13px] font-bold uppercase" style={{ fontFamily: "Arial, sans-serif" }}>Experiencia laboral</h2>{exps.map((x, i) => (
            <div key={i} className="mb-2 text-[11.5px]"><p className="font-bold">{x.puesto}</p><p>{[x.empresa, x.periodo].filter(Boolean).join(" | ")}</p>{x.detalle && <p className="whitespace-pre-line">{x.detalle}</p>}</div>))}</>}
          {edus.length > 0 && <><h2 className="mt-5 mb-1 border-b border-ink text-[13px] font-bold uppercase" style={{ fontFamily: "Arial, sans-serif" }}>Educación</h2>{edus.map((x, i) => (
            <div key={i} className="mb-2 text-[11.5px]"><p className="font-bold">{x.titulo}</p><p>{[x.institucion, x.periodo].filter(Boolean).join(" | ")}</p></div>))}</>}
          {list(d.habilidades).length > 0 && <><h2 className="mt-5 mb-1 border-b border-ink text-[13px] font-bold uppercase" style={{ fontFamily: "Arial, sans-serif" }}>Habilidades</h2><p className="text-[11.5px]">{list(d.habilidades).join(", ")}</p></>}
          {list(d.idiomas).length > 0 && <><h2 className="mt-5 mb-1 border-b border-ink text-[13px] font-bold uppercase" style={{ fontFamily: "Arial, sans-serif" }}>Idiomas</h2><p className="text-[11.5px]">{list(d.idiomas).join(", ")}</p></>}
        </div>
      )}
      {formato === "minimal" && (
        <div className="p-8">
          <div className="mb-8 flex items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl font-light tracking-tight">{nombre}</h1>
              {d.titulo && <p className="text-sm uppercase tracking-widest text-ink-soft">{d.titulo}</p>}
              <p className="mt-2 text-[11px] text-ink-soft">{contacto.join("   /   ")}</p>
            </div>
            <Foto cls="h-20 w-20 rounded-full grayscale" />
          </div>
          <div className="grid grid-cols-[1fr_30%] gap-6">{cuerpo}{extras(false)}</div>
        </div>
      )}
    </div>
  );
}
